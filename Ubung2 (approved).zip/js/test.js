"use strict";

// Your JavaScript code goes here
console.log("Hello, manana!(JS strict)");

let message = "Dies ist ein Test für die Ausgabe einer Meldung!";
alert(message);

let question = "Do you want to proceed?";
let userResponse = confirm(question);

if (userResponse) {
    console.log("User clicked OK");
    //Code to execute if the user clicked OK
} else {
    console.log("User clicked Cancel or closed the dialog.");

}

let guestList1 = `Guests:
- John
- Pete
- Mary`;

console.log(guestList1);

let guestList2 = "Guests:\n * John\n * Pete\n * Mary";
console.log(guestList2);

//Type out the second letter of the word rabit
console.log("rabbit"[1]); //it is index 1, because the first character is zero

let letter = "rabbit"[1];
console.log(letter);

//It will print out undefined, because index of 100 it doesn't exist for the word rabbit
console.log("rabbit"[100]); /*in the square brackets we write the index, 100 is non-existent*/

let myString = "Hello World";

console.log(myString.toLowerCase()) //output: "hello world"
console.log(myString.toUpperCase()); //output "HELLO WORLD"

let newString = "Hubba-hubba";

console.log(newString.indexOf("u")); //output: 1 (index of the first occurence)
console.log(newString.indexOf("Hubba")); //output" 0 )(index of the first occurence of the first letter of the word - Hubba (so the indexes are like 01234 ))

let secondString = "Substring with egg";

console.log(secondString.indexOf("i")); //first occurence of the letter i - index 6
console.log(secondString.lastIndexOf("i")); //last occurence of the letter i (index 11)

