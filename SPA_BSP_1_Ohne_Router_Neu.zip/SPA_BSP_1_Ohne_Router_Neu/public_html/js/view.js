
import * as presenter from './presenter.js';

// Private Funktionen 

// Ersetzt alle %bezeichner Texte in element durch die 
// gleichnamigen Attributwerte des Objekts
function setDataInfo(element, object) {
    let cont = element.innerHTML;
    for (let key in object) {
        let rexp = new RegExp("%" + key + "%", "g");
        cont = cont.replace(rexp, object[key]);
    }
    element.innerHTML = cont;
}
// Setzt die Navigations-Buttons in das Nav-Element des Templates in temp
function setNavButtons(templ) {
// Klonen des Button-Komponententemplate
    let buttons = document.getElementById("buttons").cloneNode(true);
    buttons.removeAttribute("id");
    // Buttons in Navigation einsetzen
    let nav = templ.querySelector("nav");
    nav.append(buttons);
}

function setSelected(ul, abtId) {
    let li = null;
    let lis = ul.querySelectorAll('li');
    // Alle zurücksetzten, selektierten suchen
    for (let l of lis) {
        l.classList.remove('selected');
        if (l.dataset.id === abtId)
            li = l;
    }
    if (li)
        li.classList.add('selected');
}

// Öffentliche Schnittstelle von View

function renderNav(abtId, abts) {

    console.log("View: Aufruf von renderNav");
    let ul = document.getElementById('nav').cloneNode(true);
    ul.removeAttribute("id");
    let liTempl = ul.firstElementChild;
    liTempl.remove();
    for (let a of abts) {
        let li = liTempl.cloneNode(true);
        if (a.id === abtId)
            li.classList.add('selected');
        ul.appendChild(li);
        setDataInfo(ul, a);

    }
    return ul;
}

function updateNavSelection(abtId) {
    console.log("View: Aufruf von updateNavSelection");
    setSelected(document.querySelector('#nav_slot ul'), abtId);
}

function renderAbtInfo(abt) {
    console.log("View: Aufruf von renderAbtInfo");
    let div = document.getElementById("abt_info").cloneNode(true);
    div.removeAttribute("id");
    setDataInfo(div, abt);
    return div;
}

function renderOverview(data) {
    console.log("View: Aufruf von renderOverView");
    // Klonen des Template-Knotens für die Seite
    let page = document.getElementById('overview').cloneNode(true);
    // Entfernen des Id-Attributs (keine Doubletten!)
    page.removeAttribute("id");
    let ul = page.querySelector("ul");
    let liTempl = ul.firstElementChild;
    // Erstellen der Buttons und Einsetzen in Template
    setNavButtons(liTempl)
    // Template für LIs aus Clone entfernen
    liTempl.remove();
    // Erstellen eines li-Elements für jedes Produkt
    for (let p of data) {
        // Klonen des Template-Knotens für das Listenelement
        let li = liTempl.cloneNode(true);
        // Einhängen in ul
        ul.appendChild(li);
        // Ersetzen der Platzhalter in ul
        setDataInfo(ul, p);
    }
    // Setzen des Platzhalters für abtId
    setDataInfo(page, data[0]);
    return page;
}

function renderDetail(data) {
    console.log("View: Aufruf von renderDetail");
    // Klonen des Template-Knotens für die Seite
    let page = document.getElementById('detail').cloneNode(true);
    // Erstellen der Buttons und Einsetzen in Template
    setNavButtons(page)
    // Entfernen des Id-Attributs (keine Doubletten!)
    page.removeAttribute("id");
    //Einsetzen der Attributwerte
    setDataInfo(page, data);
    return page;
}

export { renderNav, updateNavSelection, renderAbtInfo, renderOverview, renderDetail };

