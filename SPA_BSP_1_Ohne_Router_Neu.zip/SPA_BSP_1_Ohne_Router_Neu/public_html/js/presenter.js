
import * as model from './model.js';
import * as view from './view.js';
// Import hier nur, damit handleClick ohne Router funktioniert!
import * as presenter from './presenter.js';

let state = {};
resetState();

function resetState() {
    state = {
        abtId: -1,
        arbId: -1,
        initialized: false,
        detail: false,
        navSlotUpdate: true,
        selectionUpdate: true,
        abtInfoSlotUpdate: true
    }
}

// Eine asynchrone Funktion wird beim Aufruf angestoßen und asynchron abgearbeitet, 
// D.h. der Quellcode der aufrufenden Funktion wird weiter abgearbeitet. 
// Die asynchrone Funktion läuft parallel dazu weiter und wartet ggf. auf angeforderte Ressourcen.
async function fillNavSlot() {
    console.log("fillNavSlot start: " + new Date(Date.now()).toLocaleTimeString('de-DE'));
    state.navSlotUpdate = false;
    state.selectionUpdate = false;
    let abts = await model.getAllAbteilungen();
    let elem = view.renderNav(state.abtId, abts);
    replace('nav_slot', elem);
    console.log("fillNavSlot end: " + new Date(Date.now()).toLocaleTimeString('de-DE'));
}
// Aktualisiert den AbtInfoSlot
async function fillAbtInfoSlot() {
    console.log("fillInfoSlot start: " + new Date(Date.now()).toLocaleTimeString('de-DE'));
    state.abtInfoSlotUpdate = false;
    let result = await model.getAbteilung(state.abtId);
    let elem = view.renderAbtInfo(result);
    replace('abt_info_slot', elem);
    console.log("fillInfoSlot end: " + new Date(Date.now()).toLocaleTimeString('de-DE'));
}
// Aktualisiert die allgemeinen Elemente der Seite
function updatePage() {
    console.log("Aufruf von updatePage()");
    if (!state.initialized) {
        console.log("Initialisierung von Eventhandler.")
        document.body.addEventListener("click", handleClicks);
        state.initialized = true;
    }
    // Sequentielle Abarbeitung (mit await): dauert 4 Sekunden
    // ohne await: beide werden parallel angestoßen, dauert 2 Sekunden
    if (state.abtInfoSlotUpdate)  fillAbtInfoSlot();
    if (state.navSlotUpdate)  fillNavSlot();
    // muss nicht gemacht werden, wenn vorher der NavSlot aktualisiert wurde
    else if (state.selectionUpdate) {
        state.selectionUpdate = false;
        view.updateNavSelection(state.abtId);
    }
}

// Eventhandler für alle Click-Events auf der Seite
function handleClicks(event) {
    let source = null;
    // Behandelt werden clicks auf a-Tags, Buttons  
    // und Elemente, die in ein Li-Tag eingebunden sind.
    switch (event.target.tagName) {
        case "A":
            event.preventDefault();
            source = event.target;
            break;
        case "BUTTON" :
            source = event.target;
            break;
        default:
            source = event.target.closest("LI");
            break;
    }
    if (source) {
        let action = source.dataset.action;
        let id = source.dataset.id;
        let abtId = (action === "showOverview")? id: state.abtId;
        if (action) {
            presenter[action](abtId, id);
        }
    }
}

// Ersetzt das aktuell angezeigte Element im Container mit id
// durch ein neues Element
function replace(id, element) {
    let slot = document.getElementById(id);
    let content = slot.firstElementChild;
    if (content)
        content.remove();
    if (element) {
        slot.append(element);
    }
}


// Öffentliche Schnittstelle des Presenters

// Zeigt die Startseite der Anwendung
async function showStartPage() {
    console.log("Presenter: Aufruf von showStartPage()");
    // Bei Betreten der App soll die erste Abteilung angezeigt werden 
    let abts =  await model.getAllAbteilungen();
    state.abtId = abts[0].id;
    // Setzen der noch fehlenden Elemente der Seite
    updatePage();
    // Weiter zur Übersicht
    showOverview(state.abtId);
}

// Wird aufgerufen, wenn die Übersichtsseite angezeigt werden soll
async function showOverview(id) {
    console.log(`Presenter: Aufruf von showOverview(${id})`);
    // Nicht auf Detail-View
    state.detail = false;
    // Bei neuer id muss abtInfoSlot neu gerendert 
    // und die Selektion aktualisiert werden
    if (id !== state.abtId) {
        state.abtId = id;
        state.abtInfoSlotUpdate = true;
        state.selectionUpdate = true;
    }
    state.arbId = -1;
    // Aktualisieren der allgemeinen Elemente
    updatePage();
    // Die zu rendernden Daten vom Model beziehen
    let result = await model.getAllMitarbeiter(id);
    // Aufruf der render-Methode der View, übergeben der Daten
    let page = view.renderOverview(result);
    replace('main-content_slot', page);
}

// Wird aufgerufen, wenn die Detailansicht der Person 
// mit der id angezeigt werden soll.
async function showDetail(abtId, arbId) {
    console.log(`Presenter: Aufruf von showDetail(${abtId}, ${arbId})`);
    // Auf Detail-View
    state.detail = true;
    state.arbId = arbId;
    // Bei neuer id muss abtInfoSlot neu gerendert werden
    // und die Selektion verändert
    if (abtId !== state.abtId) {
        state.abtId = abtId;
        // Neue id, InfoSlot muss neu befüllt, Selektion markiert werden
        state.abtInfoSlotUpdate = true;
        state.selectionUpdate = true;
    }
    // Aktualisieren der allgemeinen Elemente
    updatePage();
    // Die zu rendernden Daten vom Model beziehen
    let result = await model.getMitarbeiter(arbId);
    console.log(result);
    // Aufruf der render-Methode der View, übergeben der Daten
    let page = view.renderDetail(result);
    replace('main-content_slot', page);
}

// Editorseite für das Hinzufügen eines neuen Mitarbeiters
function showAdd(id) {
    console.log(`Presenter: Aufruf von showAdd(${id})`);
    state.abtId = id;
    state.arbId = -1;
    // Aktualisieren der allgemeinen Elemente
    updatePage();
    // Rest kommt später
}

// Editorseite für das Editieren eines  Mitarbeiters
function showEdit(abtId, arbId) {
    console.log(`Presenter: Aufruf von showEdit(${abtId}, ${arbId})`);
    state.abtId = abtId;
    state.arbId = arbId;
    state.detail = false;
    // Aktualisieren der allgemeinen Elemente
    updatePage();
    // Rest kommt später
}

function save(obj) {
    console.log(`Presenter: Aufruf von save für id: ${obj.id}`);
    // Rest kommt später
}

async function deleteM(id) {
    console.log(`Presenter: Aufruf von deleteM(${id})`);
    let removed = await model.deleteMitarbeiter(id);
    alert(`Dieser Mitarbeiter wurde gelöscht: ${removed.name}`);
    // Header-Infos müssen aktualisiert werden
    state.abtInfoSlotUpdate = true;
    state.navSlotUpdate = true;
    // Bei Löschen auf der Detail-Seite zurück zur Übersicht
    if (detail) {
        showOverview(state.abtId);
    } else
        updatePage();
}


showStartPage();

export { showStartPage, showOverview, showDetail, showAdd, showEdit, deleteM };


