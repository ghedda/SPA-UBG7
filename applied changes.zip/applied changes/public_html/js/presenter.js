import * as model from './model.js';
import * as view from './view.js';

let state = {
    abtId: -1,
    arbId: -1,
    initialized: false,
    detail: false,
    navSlotUpdate: true,
    selectionUpdate: true,
    abtInfoSlotUpdate: true
};
resetState();

function resetState() {
    state = {
        abtId: -1,
        arbId: -1,
        initialized: false,
        detail: false,
        navSlotUpdate: true,
        selectionUpdate: true,
        abtInfoSlotUpdate: true
    };
}

async function fillNavSlot() {
    console.log("fillNavSlot start: " + new Date(Date.now()).toLocaleTimeString('de-DE'));
    state.navSlotUpdate = false;
    state.selectionUpdate = false;
    let abts = await model.getAllAbteilungen();
    let elem = view.renderNav(state.abtId, abts);
    replace('nav_slot', elem);
    console.log("fillNavSlot end: " + new Date(Date.now()).toLocaleTimeString('de-DE'));
}

async function fillAbtInfoSlot() {
    console.log("fillInfoSlot start: " + new Date(Date.now()).toLocaleTimeString('de-DE'));
    state.abtInfoSlotUpdate = false;
    let result = await model.getAbteilung(state.abtId);
    let elem = view.renderAbtInfo(result);
    replace('abt_info_slot', elem);
    console.log("fillInfoSlot end: " + new Date(Date.now()).toLocaleTimeString('de-DE'));
}

function updatePage() {
    console.log("Aufruf von updatePage()");
    if (!state.initialized) {
        console.log("Initialisierung von Eventhandler.")
        document.body.addEventListener("click", handleClicks);
        state.initialized = true;
    }

    // Update the general page parts based on the current state
    if (state.abtInfoSlotUpdate) {
        fillAbtInfoSlot();
    }
    if (state.navSlotUpdate) {
        fillNavSlot();
    } else if (state.selectionUpdate) {
        state.selectionUpdate = false;
        view.updateNavSelection(state.abtId);
    }
}

function handleClicks(event) {
    let source = null;
    switch (event.target.tagName) {
        case "A":
            event.preventDefault();
            source = event.target;
            break;
        case "BUTTON":
            source = event.target;
            break;
        default:
            source = event.target.closest("LI");
            break;
    }
    if (source) {
        let action = source.dataset.action;
        let id = source.dataset.id;
        let abtId = (action === "showOverview") ? id : state.abtId;
        if (action) {
            presenter[action](abtId, id);
        }
    }
}

function replace(id, element) {
    let slot = document.getElementById(id);
    let content = slot.firstElementChild;
    if (content)
        content.remove();
    if (element) {
        slot.append(element);
    }
}

// Function to show the start page
async function showStartPage() {
    console.log("Presenter: Aufruf von showStartPage()");
    let abts = await model.getAllAbteilungen();
    state.abtId = abts[0].id;
    updatePage();
    showOverview(state.abtId);
}

// Function to show the overview page
async function showOverview(id) {
    console.log(`Presenter: Aufruf von showOverview(${id})`);
    state.detail = false;
    if (id !== state.abtId) {
        state.abtId = id;
        state.abtInfoSlotUpdate = true;
        state.selectionUpdate = true;
    }
    state.arbId = -1;
    updatePage();
    let result = await model.getAllMitarbeiter(id);
    let page = view.renderOverview(result);
    replace('main-content_slot', page);
}

// Function to show the detail page
async function showDetail(abtId, arbId) {
    console.log(`Presenter: Aufruf von showDetail(${abtId}, ${arbId})`);
    state.detail = true;
    state.arbId = arbId;
    if (abtId !== state.abtId) {
        state.abtId = abtId;
        state.abtInfoSlotUpdate = true;
        state.selectionUpdate = true;
    }
    updatePage();
    let result = await model.getMitarbeiter(arbId);
    let page = view.renderDetail(result);
    replace('main-content_slot', page);
}

function showAdd(id) {
    console.log(`Presenter: Aufruf von showAdd(${id})`);
    state.abtId = id;
    state.arbId = -1;
    updatePage();
}

function showEdit(abtId, arbId) {
    console.log(`Presenter: Aufruf von showEdit(${abtId}, ${arbId})`);
    state.abtId = abtId;
    state.arbId = arbId;
    state.detail = false;
    updatePage();
}

function save(obj) {
    console.log(`Presenter: Aufruf von save für id: ${obj.id}`);
}

async function deleteM(id) {
    console.log(`Presenter: Aufruf von deleteM(${id})`);
    let removed = await model.deleteMitarbeiter(id);
    alert(`Dieser Mitarbeiter wurde gelöscht: ${removed.name}`);
    state.abtInfoSlotUpdate = true;
    state.navSlotUpdate = true;
    if (detail) {
        showOverview(state.abtId);
    } else
        updatePage();
}

showStartPage();

export { showStartPage, showOverview, showDetail, showAdd, showEdit, deleteM };
