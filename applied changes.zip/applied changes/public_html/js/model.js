
// Private Variablen und Funktionen

let mitarbeiter = new Map();
let abteilungen = new Map();
let professions = new Set(["Systemadministration", "Baugewerbe", "Fleischerei", "Einzelhandel"]);
let last_id = 14;
const DELAY = 2000;

function initData() {
    function addMitarbeiter(id, name, date, job, email, abt) {
        let arbeiter = new Mitarbeiter(id, name, date, job, email, abt);
        let abteilung = abteilungen.get(abt);
        abteilung.addMitarbeiter();
        mitarbeiter.set(id, arbeiter);
    }
    abteilungen.set("a", new Abteilung("Abteilung 1", 'a'));
    abteilungen.set("b", new Abteilung("Abteilung 2", 'b'));
    abteilungen.set("c", new Abteilung("Abteilung 3", 'c'));
    addMitarbeiter("1", "Ella Mustermann", "1963-10-24", "Systemadministration", "ellam@gmx.de", "a");
    addMitarbeiter("2", "Harry Hurtig", "1985-06-04", "Baugewerbe", "harryh@gmail.com", "a");
    addMitarbeiter("3", "Erna Huber", "1999-01-14", "Fleischerei", "erna@gmail.com", "a");
    addMitarbeiter("4", "Erwin Huber", "1989-11-07", "Einzelhandel", "erwin@gmail.com", "a");
    addMitarbeiter("5", "Anna Huber", "1992-03-02", "Einzelhandel", "anna@gmail.com", "a");
    addMitarbeiter("6", "Ella Lanzmann", "1963-10-24", "Systemadministration", "ellam@gmx.de", "b");
    addMitarbeiter("7", "Harry Heller", "1985-06-04", "Baugewerbe", "harryh@gmail.com", "b");
    addMitarbeiter("8", "Erna Müller", "1999-01-14", "Fleischerei", "erna@gmail.com", "b");
    addMitarbeiter("9", "Erwin Walther", "1989-11-07", "Einzelhandel", "erwin@gmail.com", "b");
    addMitarbeiter("10", "Anna Ammer", "1992-03-02", "Einzelhandel", "anna@gmail.com", "b");
    addMitarbeiter("11", "Ella Maier", "1963-10-24", "Systemadministration", "ellam@gmx.de", "c");
    addMitarbeiter("12", "Harry Hensel", "1985-06-04", "Baugewerbe", "harryh@gmail.com", "c");
    addMitarbeiter("13", "Erna Ebermann", "1999-01-14", "Fleischerei", "erna@gmail.com", "c");
    addMitarbeiter("14", "Erwin Ekel", "1989-11-07", "Einzelhandel", "erwin@gmail.com", "c");
}


function Mitarbeiter(id, name, date, job, email, abt) {
    this.id = id;
    this.name = name;
    this.date_of_birth = date;
    this.job = job;
    this.email = email;
    this.abtId = abt;
}

function Abteilung(name, id) {
    this.id = id;
    this.name = name;
    this.number = 0;
}

Mitarbeiter.prototype = {
    constructor: Mitarbeiter,
    // getter-Methode für Berechnung des Alters
    get age() {
        let akt = new Date();
        let birth = new Date(this.date_of_birth);
        let age = akt.getFullYear() - birth.getFullYear();
        if (akt.getMonth() < birth.getMonth())
            age--;
        if (akt.getMonth() === birth.getMonth() && akt.getDay() < birth.getDay())
            age--;
        return age;
    }
}

Abteilung.prototype = {
    constructor: Abteilung,
    addMitarbeiter() {
        this.number++;
    },
    removeMitarbeiter() {
        this.number--;
    }
};

function makePromise(value) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(value);
        }, DELAY);
    });
}

// Öffentliche Schnittstelle von Model

async function getAllMitarbeiter(abtId) {
//    console.log(mitarbeiter.values());
//    console.log(abtId);
    let allevonAbt = [...mitarbeiter.values()].filter((m) => (m.abtId === abtId));
    return makePromise(allevonAbt);
}

async function getAllAbteilungen() {
    return makePromise([...abteilungen.values()]);
}

async function getMitarbeiter(id) {
    let data = mitarbeiter.get(id);
    return makePromise(data);
}

async function getAbteilung(id) {
    let data = abteilungen.get(id);
    return makePromise(data);
}

async function deleteMitarbeiter(id) {
//    console.log(id);
//    console.log(mitarbeiter);
    let removed = mitarbeiter.get(id);
//    console.log(removed);
    let abt = abteilungen.get(removed.abtId);
//    console.log(abt);
    abt.removeMitarbeiter();
    mitarbeiter.delete(id);
    return makePromise(removed);
}

initData();

export { getAllMitarbeiter,
        getAllAbteilungen,
        getMitarbeiter,
        getAbteilung,
        deleteMitarbeiter
};