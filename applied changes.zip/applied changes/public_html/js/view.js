import * as presenter from './presenter.js';

// Private Funktionen 

// Ersetzt alle %bezeichner Texte in element durch die 
// gleichnamigen Attributwerte des Objekts
// Private function to replace placeholders with object attribute values
function setDataInfo(element, object) {
    let cont = element.innerHTML;
    for (let key in object) {
        let rexp = new RegExp("%" + key + "%", "g");
        cont = cont.replace(rexp, object[key]);
    }
    element.innerHTML = cont;
}

// Public function to set navigation buttons
function setNavButtons(templ) {
    let buttons = document.getElementById("buttons").cloneNode(true);
    buttons.removeAttribute("id");
    let nav = templ.querySelector("nav");
    nav.append(buttons);
}

// Public function to update the selected item in the navigation
function setSelected(ul, abtId) {
    let li = null;
    let lis = ul.querySelectorAll('li');
    for (let l of lis) {
        l.classList.remove('selected');
        if (l.dataset.id === abtId)
            li = l;
    }
    if (li)
        li.classList.add('selected');
}

// Public function to render the navigation
function renderNav(abtId, abts) {
    let ul = document.getElementById('nav').cloneNode(true);
    ul.removeAttribute("id");
    let liTempl = ul.firstElementChild;
    liTempl.remove();
    for (let a of abts) {
        let li = liTempl.cloneNode(true);
        if (a.id === abtId)
            li.classList.add('selected');
        ul.appendChild(li);
        setDataInfo(ul, a);
    }
    return ul;
}

// Public function to update the navigation selection
function updateNavSelection(abtId) {
    setSelected(document.querySelector('#nav_slot ul'), abtId);
}

// Public function to render the department information
function renderAbtInfo(abt) {
    let div = document.getElementById("abt_info").cloneNode(true);
    div.removeAttribute("id");
    setDataInfo(div, abt);
    return div;
}

// Public function to render the overview page
function renderOverview(data) {
    let page = document.getElementById('overview').cloneNode(true);
    page.removeAttribute("id");
    let ul = page.querySelector("ul");
    let liTempl = ul.firstElementChild;
    setNavButtons(liTempl)
    liTempl.remove();
    for (let p of data) {
        let li = liTempl.cloneNode(true);
        ul.appendChild(li);
        setDataInfo(ul, p);
    }
    setDataInfo(page, data[0]);
    return page;
}

// Public function to render the detail page
function renderDetail(data) {
    let page = document.getElementById('detail').cloneNode(true);
    setNavButtons(page)
    page.removeAttribute("id");
    setDataInfo(page, data);
    return page;
}

// Public function to render the blog overview
function renderBlogOverview(posts) {
    let page = document.getElementById('blog_overview').cloneNode(true);
    page.removeAttribute("id");
    let ul = page.querySelector("ul");
    let liTempl = ul.firstElementChild;
    liTempl.remove();
    for (let post of posts) {
        let li = liTempl.cloneNode(true);
        setDataInfo(li, post);
        ul.appendChild(li);
    }
    return page;
}

// Public function to render the post detail view
function renderPostDetail(post) {
    let page = document.getElementById('post_detail').cloneNode(true);
    page.removeAttribute("id");
    setDataInfo(page, post);
    return page;
}

export { renderNav, updateNavSelection, renderAbtInfo, renderOverview, renderDetail, renderBlogOverview, renderPostDetail };
